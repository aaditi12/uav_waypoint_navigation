# Autonomous ROS 2 UAV Waypoint Navigation & Obstacle Avoidance

Simulation-only (no PX4, no real flight controller) autonomous drone system built on
**ROS 2 Humble + Gazebo Classic**, matching the project brief exactly:

- Autonomous takeoff and landing
- GPS-style waypoint navigation (local ENU coordinates)
- Real-time reactive obstacle avoidance using a 360° LiDAR
- Mission planning with multiple waypoints
- Return-to-home (RTH)
- Live visualization in RViz2 (odometry, LiDAR, planned path, flown path)
- Flight path visualization in Gazebo (waypoint markers + the UAV itself flying the route)
- Mission status monitoring (`/uav/mission_status`)
- Emergency stop + automatic safe landing
- Modular ROS 2 node architecture (5 packages, single-responsibility nodes)

## Why "kinematic" flight instead of a physics-based flight controller

The brief explicitly asks to avoid PX4/real-flight-controller complexity. Instead of
simulating rotor thrust/torque, `uav_control/kinematic_controller.py` is the single
node that owns the UAV's true pose: it steps the pose toward a commanded target at a
bounded linear/yaw rate and pushes it into Gazebo each tick via the `gazebo_ros_state`
plugin's `/gazebo/set_entity_state` service. Every other node (takeoff/land, mission
manager, obstacle avoidance) just asks the controller to go somewhere — this is what
keeps the system simple, reliable in a software-rendered VM, and easy to reason about,
while still demonstrating real autonomous-navigation concepts end to end.

## Package layout

```
uav_ws/src/
  uav_msgs/         Custom interfaces: MissionStatus.msg, ObstacleStatus.msg, GoToPose.srv
  uav_description/  Quadrotor URDF/xacro (body + 4 rotors + 360° LiDAR + front camera)
  uav_gazebo/        obstacle_world.world (5 obstacles + gazebo_ros_state plugin) + spawn launch
  uav_control/       kinematic_controller.py, takeoff_land_node.py
  uav_navigation/    obstacle_avoidance.py, mission_manager.py, safety_monitor.py,
                      path_visualizer.py, camera_view.py (OpenCV overlay)
  uav_bringup/       uav_sim.launch.py (everything), RViz config, waypoints.yaml params
```

## Node responsibilities

| Node | Package | Job |
|---|---|---|
| `uav_controller` | uav_control | Ground-truth pose, `/uav/goto` service, pushes pose to Gazebo, blends in avoidance |
| `takeoff_land_node` | uav_control | `/uav/takeoff`, `/uav/land` Trigger services (thin wrappers over `/uav/goto`) |
| `obstacle_avoidance` | uav_navigation | Reads `/uav/scan`, publishes `/uav/obstacle_status` with a suggested escape vector |
| `mission_manager` | uav_navigation | FSM: TAKEOFF → NAVIGATING → RETURNING → LANDING; `/uav/start_mission`, `/uav/return_home` |
| `safety_monitor` | uav_navigation | Simulated battery drain, proximity/battery-triggered emergency stop |
| `path_visualizer` | uav_navigation | Publishes `/uav/flown_path` (nav_msgs/Path) for RViz |
| `camera_view` | uav_navigation | OpenCV overlay of mission status onto the simulated front camera feed |

## Quick start

```bash
cd uav_ws
bash run.sh              # first run builds with colcon, then launches Gazebo + RViz2
# add --clean to force a full rebuild:  bash run.sh --clean
```

Wait for Gazebo and RViz2 windows to appear (~10s), then in a **second terminal**:

```bash
bash mission_control.sh start      # takeoff -> waypoints -> RTH -> land
bash mission_control.sh status     # print current MissionStatus
bash mission_control.sh emergency  # manually trigger emergency stop (demo)
bash mission_control.sh clear      # clear the emergency latch
bash mission_control.sh rth        # abort straight to return-to-home
```

Or call services directly:
```bash
ros2 service call /uav/start_mission std_srvs/srv/Trigger {}
ros2 topic echo /uav/mission_status
ros2 topic echo /uav/battery_state
```

## Mission waypoints

Edit `src/uav_bringup/config/waypoints.yaml` — `waypoints_x/y/z` under `mission_manager`.
Coordinates are local ENU meters (documented as simulated-GPS-derived local coordinates,
since this is a from-scratch simulation with no lat/lon GPS plugin). The default mission
flies past 5 obstacles in `obstacle_world.world` so you can watch reactive avoidance
kick in on the way to waypoints 2 and 3.

## Key topics & services

**Topics:** `/uav/odom`, `/uav/pose`, `/uav/scan`, `/uav/obstacle_status`,
`/uav/avoidance_active`, `/uav/battery_state`, `/uav/emergency_stop`,
`/uav/mission_status`, `/uav/planned_path`, `/uav/flown_path`, `/uav/camera/annotated`

**Services:** `/uav/goto`, `/uav/takeoff`, `/uav/land`, `/uav/start_mission`,
`/uav/return_home`, `/uav/emergency_stop_now`, `/uav/trigger_emergency`, `/uav/clear_emergency`

## VM / environment notes (matches your existing setup)

- Ubuntu 22.04, ROS 2 Humble, Gazebo Classic, `LIBGL_ALWAYS_SOFTWARE=1` (already set in `run.sh`)
- Rebuild pattern if things get weird: `rm -rf build/ install/ log/ && colcon build --symlink-install`
  (or just `bash run.sh --clean`)
- `cv_bridge` and `python3-opencv` need to be installed for `camera_view.py`:
  `sudo apt install ros-humble-cv-bridge python3-opencv`
- If `/gazebo/set_entity_state` never becomes available, confirm the
  `gazebo_ros_state` plugin loaded — check Gazebo server console output for errors on
  `libgazebo_ros_state.so`, and confirm `ros-humble-gazebo-ros-pkgs` is installed.
- If the UAV doesn't move: check `ros2 service list | grep goto` and
  `ros2 topic hz /uav/odom` — the controller node must be alive and the entity name in
  `waypoints.yaml` (`entity_name: 'uav'`) must match the name used in `spawn_uav.launch.py`
  (`-entity uav`).
- If TF/RViz show nothing: Fixed Frame in the provided RViz config is `map`, and the
  controller broadcasts `map -> base_link` directly (no separate odom frame, since this
  is a ground-truth kinematic sim, not a localization stack).

## Extending

- Swap `mission_manager`'s straight-line waypoint following for a lawn-mower / spline
  planner without touching the controller.
- Add `slam_toolbox` for an indoor variant (already a soft dependency in Software list) —
  point it at `/uav/scan` and `/uav/odom`, same pattern as your other SLAM projects.
- Replace `obstacle_avoidance.py`'s reactive escape-vector logic with a proper potential-
  field or VFH algorithm if you want a stronger avoidance demo.
