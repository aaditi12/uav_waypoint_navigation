#!/bin/bash
# Build (if needed) and launch the full autonomous UAV simulation.
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=== Autonomous UAV Waypoint Navigation & Obstacle Avoidance ==="

source /opt/ros/humble/setup.bash

export LIBGL_ALWAYS_SOFTWARE=1

if [ "$1" == "--clean" ]; then
    echo "[run.sh] Clean rebuild requested..."
    rm -rf build/ install/ log/
    shift
fi

if [ ! -d "install" ]; then
    echo "[run.sh] Building workspace with colcon..."
    colcon build --symlink-install
fi

source install/setup.bash

echo "[run.sh] Launching Gazebo + UAV + navigation stack + RViz2 ..."
echo "[run.sh] Once Gazebo/RViz are up (~10s), start the mission in another terminal with:"
echo "           bash mission_control.sh start"
echo ""

ros2 launch uav_bringup uav_sim.launch.py "$@"
