import os
import tempfile
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, ExecuteProcess, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


MARKER_SDF = """<?xml version="1.0"?>
<sdf version="1.6">
  <model name="{name}">
    <static>true</static>
    <pose>{x} {y} {z} 0 0 0</pose>
    <link name="link">
      <visual name="visual">
        <geometry><sphere><radius>0.15</radius></sphere></geometry>
        <material>
          <ambient>1 0.85 0 0.9</ambient>
          <diffuse>1 0.85 0 0.9</diffuse>
        </material>
        <cast_shadows>false</cast_shadows>
      </visual>
    </link>
  </model>
</sdf>"""

# Must match uav_bringup/config/waypoints.yaml
WAYPOINTS = [
    (5.0, 0.0, 3.0),
    (8.0, 3.0, 3.5),
    (12.0, -2.0, 3.0),
    (16.0, 0.0, 3.5),
]


def generate_launch_description():
    gazebo_pkg = get_package_share_directory('gazebo_ros')
    uav_gazebo_pkg = get_package_share_directory('uav_gazebo')
    uav_desc_pkg = get_package_share_directory('uav_description')

    world_path = os.path.join(uav_gazebo_pkg, 'worlds', 'obstacle_world.world')
    xacro_path = os.path.join(uav_desc_pkg, 'urdf', 'uav.urdf.xacro')

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(gazebo_pkg, 'launch', 'gazebo.launch.py')
        ),
        launch_arguments={'world': world_path, 'verbose': 'false'}.items()
    )

    robot_description = Command(['xacro ', xacro_path])

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_description, 'use_sim_time': True}]
    )

    spawn_uav = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        name='spawn_uav',
        arguments=['-topic', 'robot_description', '-entity', 'uav',
                   '-x', '0', '-y', '0', '-z', '0.1'],
        output='screen'
    )

    ld = LaunchDescription([gazebo, robot_state_publisher])

    # Spawn UAV a few seconds after Gazebo starts (avoids race condition)
    ld.add_action(TimerAction(period=3.0, actions=[spawn_uav]))

    # Spawn visual-only waypoint markers so the mission path is visible in Gazebo.
    # spawn_entity.py only supports -file / -topic / -database / -stdin (no
    # -string flag), so write each marker's SDF to a temp file and use -file.
    marker_dir = tempfile.mkdtemp(prefix='uav_waypoint_markers_')
    for i, (x, y, z) in enumerate(WAYPOINTS):
        sdf = MARKER_SDF.format(name=f'waypoint_marker_{i}', x=x, y=y, z=z)
        sdf_path = os.path.join(marker_dir, f'waypoint_marker_{i}.sdf')
        with open(sdf_path, 'w') as f:
            f.write(sdf)
        marker_proc = ExecuteProcess(
            cmd=['ros2', 'run', 'gazebo_ros', 'spawn_entity.py',
                 '-entity', f'waypoint_marker_{i}',
                 '-file', sdf_path,
                 '-x', str(x), '-y', str(y), '-z', str(z)],
            output='screen'
        )
        ld.add_action(TimerAction(period=6.0 + i * 0.5, actions=[marker_proc]))

    return ld
