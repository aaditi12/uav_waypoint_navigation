#!/usr/bin/env python3
"""
safety_monitor.py

- Simulates a slowly depleting battery so the demo has something realistic to
  monitor (/uav/battery_state).
- Continuously publishes the emergency-stop flag on /uav/emergency_stop
  (consumed by kinematic_controller, which freezes/hovers on True).
- Exposes /uav/trigger_emergency (std_srvs/Trigger) so a user can manually
  fire an emergency stop from the CLI to demo the safe-landing behaviour:
      ros2 service call /uav/trigger_emergency std_srvs/srv/Trigger {}
- Auto-triggers emergency if the LiDAR reports something dangerously close
  (tighter threshold than the normal reactive-avoidance safety distance) or
  if the simulated battery runs critically low.
"""
import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool, Float32
from std_srvs.srv import Trigger

from uav_msgs.msg import ObstacleStatus


class SafetyMonitor(Node):
    def __init__(self):
        super().__init__('safety_monitor')

        self.declare_parameter('battery_drain_per_sec', 0.15)   # % per second
        self.declare_parameter('critical_battery_pct', 8.0)
        self.declare_parameter('critical_obstacle_distance', 0.4)  # meters
        self.declare_parameter('update_rate', 5.0)

        self.drain_rate = self.get_parameter('battery_drain_per_sec').value
        self.critical_batt = self.get_parameter('critical_battery_pct').value
        self.critical_dist = self.get_parameter('critical_obstacle_distance').value

        self.battery = 100.0
        self.emergency = False
        self._last_obstacle_dist = -1.0

        self.emergency_pub = self.create_publisher(Bool, '/uav/emergency_stop', 10)
        self.battery_pub = self.create_publisher(Float32, '/uav/battery_state', 10)

        self.create_subscription(ObstacleStatus, '/uav/obstacle_status', self._obstacle_cb, 10)
        self.create_service(Trigger, '/uav/trigger_emergency', self._manual_trigger_cb)
        self.create_service(Trigger, '/uav/clear_emergency', self._clear_cb)

        rate = self.get_parameter('update_rate').value
        self.create_timer(1.0 / rate, self._tick)

        self.get_logger().info('Safety monitor active (battery sim + proximity watchdog).')

    def _obstacle_cb(self, msg: ObstacleStatus):
        self._last_obstacle_dist = msg.min_distance

    def _manual_trigger_cb(self, request, response):
        self.emergency = True
        self.get_logger().error('Manual EMERGENCY STOP triggered via service call.')
        response.success = True
        response.message = 'Emergency stop engaged.'
        return response

    def _clear_cb(self, request, response):
        self.emergency = False
        self.get_logger().info('Emergency state cleared.')
        response.success = True
        response.message = 'Emergency cleared, mission may resume.'
        return response

    def _tick(self):
        dt = 1.0 / self.get_parameter('update_rate').value
        self.battery = max(0.0, self.battery - self.drain_rate * dt)

        if not self.emergency:
            if 0.0 < self._last_obstacle_dist < self.critical_dist:
                self.get_logger().error(
                    f'Obstacle critically close ({self._last_obstacle_dist:.2f} m) - auto emergency stop.')
                self.emergency = True
            elif self.battery <= self.critical_batt:
                self.get_logger().error(
                    f'Battery critical ({self.battery:.1f}%) - auto emergency stop / land now.')
                self.emergency = True

        self.emergency_pub.publish(Bool(data=self.emergency))
        self.battery_pub.publish(Float32(data=self.battery))


def main(args=None):
    rclpy.init(args=args)
    node = SafetyMonitor()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
