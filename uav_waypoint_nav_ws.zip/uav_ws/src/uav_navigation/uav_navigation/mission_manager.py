#!/usr/bin/env python3
"""
mission_manager.py

Top-level mission FSM for the autonomous UAV:

    IDLE -> TAKEOFF -> NAVIGATING (waypoint 1..N, obstacle avoidance is
            transparent - handled inside kinematic_controller) -> RETURNING
            -> LANDING -> LANDED

    Any time /uav/emergency_stop goes True, the mission is interrupted and the
    UAV performs a safe landing at its current position (EMERGENCY -> LANDED).

Services:
    /uav/start_mission  (std_srvs/Trigger) - begin the loaded waypoint mission
    /uav/return_home    (std_srvs/Trigger) - abort current leg and RTH now

Publishes:
    /uav/mission_status (uav_msgs/MissionStatus) at 5 Hz
    /uav/planned_path   (nav_msgs/Path) once, for RViz display of the mission plan
"""
import math
import threading
import time

import rclpy
from rclpy.node import Node
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor

from std_srvs.srv import Trigger
from std_msgs.msg import Bool, Float32
from nav_msgs.msg import Odometry, Path
from geometry_msgs.msg import PoseStamped

from uav_msgs.msg import MissionStatus
from uav_msgs.srv import GoToPose


class MissionManager(Node):
    def __init__(self):
        super().__init__('mission_manager')

        self.declare_parameter('waypoints_x', [5.0, 8.0, 12.0, 16.0])
        self.declare_parameter('waypoints_y', [0.0, 3.0, -2.0, 0.0])
        self.declare_parameter('waypoints_z', [3.0, 3.5, 3.0, 3.5])
        self.declare_parameter('home_x', 0.0)
        self.declare_parameter('home_y', 0.0)
        self.declare_parameter('cruise_altitude', 3.0)
        self.declare_parameter('waypoint_tolerance', 0.4)
        self.declare_parameter('auto_start', False)

        xs = self.get_parameter('waypoints_x').value
        ys = self.get_parameter('waypoints_y').value
        zs = self.get_parameter('waypoints_z').value
        self.waypoints = list(zip(xs, ys, zs))
        self.home = (self.get_parameter('home_x').value, self.get_parameter('home_y').value)
        self.tolerance = self.get_parameter('waypoint_tolerance').value

        cb = ReentrantCallbackGroup()

        self.state = 'IDLE'
        self.current_wp_idx = -1
        self.battery = 100.0
        self.avoidance_active = False
        self.emergency = False
        self.last_odom = None
        self._mission_lock = threading.Lock()
        self._mission_thread = None

        self.status_pub = self.create_publisher(MissionStatus, '/uav/mission_status', 10)
        self.planned_path_pub = self.create_publisher(Path, '/uav/planned_path', 10)

        self.create_subscription(Odometry, '/uav/odom', self._odom_cb, 10, callback_group=cb)
        self.create_subscription(Bool, '/uav/emergency_stop', self._emergency_cb, 10, callback_group=cb)
        self.create_subscription(Bool, '/uav/avoidance_active', self._avoid_cb, 10, callback_group=cb)
        self.create_subscription(Float32, '/uav/battery_state', self._batt_cb, 10, callback_group=cb)

        self.goto_cli = self.create_client(GoToPose, '/uav/goto', callback_group=cb)
        self.takeoff_cli = self.create_client(Trigger, '/uav/takeoff', callback_group=cb)
        self.land_cli = self.create_client(Trigger, '/uav/land', callback_group=cb)
        self.clear_emergency_cli = self.create_client(Trigger, '/uav/clear_emergency', callback_group=cb)

        self.create_service(Trigger, '/uav/start_mission', self._start_mission_cb, callback_group=cb)
        self.create_service(Trigger, '/uav/return_home', self._return_home_cb, callback_group=cb)
        self.create_service(Trigger, '/uav/emergency_stop_now', self._emergency_now_cb, callback_group=cb)

        self.create_timer(0.2, self._publish_status, callback_group=cb)
        self._publish_planned_path()

        if self.get_parameter('auto_start').value:
            self.get_logger().info('auto_start=true, launching mission automatically in 5s.')
            threading.Timer(5.0, self._run_mission).start()

        self.get_logger().info(
            f'Mission manager ready with {len(self.waypoints)} waypoints. '
            'Call /uav/start_mission to begin.')

    # ------------------------------------------------------------ callbacks
    def _odom_cb(self, msg: Odometry):
        self.last_odom = msg

    def _emergency_cb(self, msg: Bool):
        was = self.emergency
        self.emergency = msg.data
        if self.emergency and not was and self.state not in ('EMERGENCY', 'LANDED', 'IDLE'):
            self.get_logger().error('Emergency flag set - interrupting mission for safe landing.')
            self._trigger_emergency_landing()

    def _avoid_cb(self, msg: Bool):
        self.avoidance_active = msg.data

    def _batt_cb(self, msg: Float32):
        self.battery = msg.data

    def _emergency_now_cb(self, request, response):
        self._trigger_emergency_landing()
        response.success = True
        response.message = 'Emergency landing sequence started.'
        return response

    def _trigger_emergency_landing(self):
        if self._mission_thread and self._mission_thread.is_alive():
            # let the running mission thread notice self.state == EMERGENCY and bail out
            pass
        self.state = 'EMERGENCY'
        t = threading.Thread(target=self._emergency_land_sequence, daemon=True)
        t.start()

    # -------------------------------------------------------------- helpers
    def _call_trigger(self, client, name, timeout=60.0):
        if not client.wait_for_service(timeout_sec=5.0):
            self.get_logger().error(f'{name} service unavailable.')
            return False
        future = client.call_async(Trigger.Request())
        waited = 0.0
        while not future.done() and waited < timeout:
            time.sleep(0.1)
            waited += 0.1
        if not future.done() or future.result() is None:
            self.get_logger().error(f'{name} call timed out.')
            return False
        res = future.result()
        if not res.success:
            self.get_logger().error(f'{name} failed: {res.message}')
        return res.success

    def _call_goto(self, x, y, z, timeout=60.0):
        if not self.goto_cli.wait_for_service(timeout_sec=5.0):
            return False
        req = GoToPose.Request()
        req.target.position.x = x
        req.target.position.y = y
        req.target.position.z = z
        req.target.orientation.w = 1.0
        req.tolerance = self.tolerance
        req.timeout = timeout
        future = self.goto_cli.call_async(req)
        waited = 0.0
        while not future.done() and waited < timeout + 5.0:
            time.sleep(0.1)
            waited += 0.1
        if not future.done() or future.result() is None:
            return False
        return future.result().success

    def _distance_to(self, x, y, z):
        if self.last_odom is None:
            return -1.0
        p = self.last_odom.pose.pose.position
        return math.sqrt((x - p.x) ** 2 + (y - p.y) ** 2 + (z - p.z) ** 2)

    def _publish_planned_path(self):
        path = Path()
        path.header.frame_id = 'map'
        path.header.stamp = self.get_clock().now().to_msg()
        for (x, y, z) in [(self.home[0], self.home[1], 0.0)] + self.waypoints + \
                          [(self.home[0], self.home[1], self.waypoints[-1][2] if self.waypoints else 0.0)]:
            ps = PoseStamped()
            ps.header = path.header
            ps.pose.position.x, ps.pose.position.y, ps.pose.position.z = x, y, z
            ps.pose.orientation.w = 1.0
            path.poses.append(ps)
        self.planned_path_pub.publish(path)

    def _publish_status(self):
        msg = MissionStatus()
        msg.state = self.state
        msg.current_waypoint = self.current_wp_idx + 1
        msg.total_waypoints = len(self.waypoints)
        if 0 <= self.current_wp_idx < len(self.waypoints):
            wx, wy, wz = self.waypoints[self.current_wp_idx]
            msg.distance_remaining = max(0.0, self._distance_to(wx, wy, wz))
        else:
            msg.distance_remaining = 0.0
        msg.battery_percent = self.battery
        msg.obstacle_avoidance_active = self.avoidance_active
        self.status_pub.publish(msg)

    # ---------------------------------------------------------------- FSM
    def _start_mission_cb(self, request, response):
        with self._mission_lock:
            if self._mission_thread and self._mission_thread.is_alive():
                response.success = False
                response.message = 'Mission already in progress.'
                return response
            if self.emergency:
                response.success = False
                response.message = 'Cannot start: UAV is in EMERGENCY state. Clear it first.'
                return response
            self._mission_thread = threading.Thread(target=self._run_mission, daemon=True)
            self._mission_thread.start()
        response.success = True
        response.message = 'Mission started.'
        return response

    def _return_home_cb(self, request, response):
        with self._mission_lock:
            if self._mission_thread and self._mission_thread.is_alive():
                response.success = False
                response.message = 'Mission already running; it will RTH automatically after current leg, or use emergency_stop_now to abort immediately.'
                return response
            self._mission_thread = threading.Thread(target=self._run_rth_and_land, daemon=True)
            self._mission_thread.start()
        response.success = True
        response.message = 'Returning home.'
        return response

    def _run_mission(self):
        self.get_logger().info('=== MISSION START ===')
        self.state = 'TAKEOFF'
        if not self._call_trigger(self.takeoff_cli, 'takeoff'):
            self.get_logger().error('Takeoff failed - aborting mission.')
            self.state = 'IDLE'
            return

        self.state = 'NAVIGATING'
        for i, (x, y, z) in enumerate(self.waypoints):
            if self.emergency:
                return  # emergency handler takes over
            self.current_wp_idx = i
            self.get_logger().info(f'Navigating to waypoint {i + 1}/{len(self.waypoints)}: ({x}, {y}, {z})')
            ok = self._call_goto(x, y, z)
            if not ok and not self.emergency:
                self.get_logger().warn(f'Waypoint {i + 1} not confirmed reached (timeout) - continuing mission.')

        if self.emergency:
            return

        self.current_wp_idx = len(self.waypoints)
        self._run_rth_and_land()

    def _run_rth_and_land(self):
        self.state = 'RETURNING'
        self.get_logger().info('Returning to home position.')
        cruise = self.get_parameter('cruise_altitude').value
        if self.emergency:
            return
        self._call_goto(self.home[0], self.home[1], cruise)

        if self.emergency:
            return
        self.state = 'LANDING'
        self.get_logger().info('Landing at home.')
        self._call_trigger(self.land_cli, 'land')
        self.state = 'LANDED'
        self.current_wp_idx = -1
        self.get_logger().info('=== MISSION COMPLETE: UAV LANDED AT HOME ===')

    def _emergency_land_sequence(self):
        self.get_logger().error('=== EMERGENCY: hovering in place, then performing safe landing ===')
        self.state = 'EMERGENCY'
        # 1) Let the controller finish freezing the target pose and the vehicle
        #    settle into a stable hover before attempting anything else.
        time.sleep(2.0)

        # 2) Auto-clear the emergency latch so a controlled descent is allowed.
        #    (kinematic_controller refuses new /uav/goto targets while the
        #    emergency flag is set, so this is required before landing.)
        self._call_trigger(self.clear_emergency_cli, 'clear_emergency')

        # 3) Land straight down at the current position - no lateral travel.
        self.get_logger().warn('Descending for safe landing at current position.')
        self._call_trigger(self.land_cli, 'land')

        self.state = 'LANDED'
        self.current_wp_idx = -1
        self.get_logger().error('=== EMERGENCY SAFE LANDING COMPLETE ===')


def main(args=None):
    rclpy.init(args=args)
    node = MissionManager()
    executor = MultiThreadedExecutor(num_threads=6)
    executor.add_node(node)
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
