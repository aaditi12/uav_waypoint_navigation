#!/usr/bin/env python3
"""
camera_view.py

Subscribes to the UAV's simulated front camera (/uav/camera/image_raw) and
overlays live mission status (state, battery, obstacle-avoidance flag)
directly onto the video frame, republishing it on /uav/camera/annotated
for viewing in rqt_image_view or RViz2's Image display.

Image conversion is done with a small hand-rolled numpy codec rather than
cv_bridge. cv_bridge's C++ extension (cv_bridge_boost) is compiled against
a fixed NumPy C-API version on Humble's apt packages; if a newer NumPy
(2.x) is installed via pip, calling into that extension can segfault the
whole process (AttributeError: _ARRAY_API not found, then SIGSEGV). A
Python try/except cannot catch a native segfault, so the only reliable
fix is to avoid calling into that extension at all for the encodings we
actually use here. If you ever need an encoding not listed in
_SUPPORTED_ENCODINGS, extend the codec below rather than falling back to
cv_bridge.
"""
import numpy as np
import cv2
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image

from uav_msgs.msg import MissionStatus

# encoding -> (channels, needs BGR<->RGB byte swap for OpenCV)
_SUPPORTED_ENCODINGS = {
    'bgr8': (3, False),
    'rgb8': (3, True),
    'mono8': (1, False),
    'bgra8': (4, False),
    'rgba8': (4, True),
}


def imgmsg_to_bgr(msg: Image) -> np.ndarray:
    """Convert a sensor_msgs/Image to a BGR (or mono) numpy array without cv_bridge."""
    if msg.encoding not in _SUPPORTED_ENCODINGS:
        raise ValueError(f'unsupported encoding: {msg.encoding}')
    channels, needs_swap = _SUPPORTED_ENCODINGS[msg.encoding]

    raw = np.frombuffer(msg.data, dtype=np.uint8).reshape(msg.height, msg.step)
    row_bytes = msg.width * channels
    frame = raw[:, :row_bytes].reshape(msg.height, msg.width, channels) if channels > 1 \
        else raw[:, :row_bytes].reshape(msg.height, msg.width)

    if needs_swap and channels >= 3:
        frame = frame.copy()
        frame[..., :3] = frame[..., :3][..., ::-1]

    return frame


def bgr_to_imgmsg(frame: np.ndarray, header) -> Image:
    """Convert a BGR/mono numpy array back to a sensor_msgs/Image without cv_bridge."""
    msg = Image()
    msg.header = header
    msg.height, msg.width = frame.shape[0], frame.shape[1]
    channels = frame.shape[2] if frame.ndim == 3 else 1
    msg.encoding = 'bgr8' if channels == 3 else ('bgra8' if channels == 4 else 'mono8')
    msg.is_bigendian = 0
    msg.step = msg.width * channels
    msg.data = np.ascontiguousarray(frame).tobytes()
    return msg


class CameraView(Node):
    def __init__(self):
        super().__init__('camera_view')
        self.status_text = 'state=IDLE  wp=0/0  batt=100%'
        self._degraded_logged = False

        self.pub = self.create_publisher(Image, '/uav/camera/annotated', 10)
        self.create_subscription(Image, '/uav/camera/image_raw', self._image_cb, 10)
        self.create_subscription(MissionStatus, '/uav/mission_status', self._status_cb, 10)

        self.get_logger().info('Camera view (OpenCV overlay) ready.')

    def _status_cb(self, msg: MissionStatus):
        avoid = 'AVOIDING' if msg.obstacle_avoidance_active else 'clear'
        self.status_text = (f'state={msg.state}  wp={msg.current_waypoint}/{msg.total_waypoints}  '
                             f'batt={msg.battery_percent:.0f}%  {avoid}')

    def _image_cb(self, msg: Image):
        try:
            frame = imgmsg_to_bgr(msg)
        except Exception as e:  # noqa: BLE001
            if not self._degraded_logged:
                self.get_logger().warn(
                    f'camera_view: could not decode image (encoding={msg.encoding}): {e}. '
                    'Skipping overlay for this and future frames on this encoding.'
                )
                self._degraded_logged = True
            return

        try:
            cv2.rectangle(frame, (0, 0), (frame.shape[1], 22), (0, 0, 0), -1)
            cv2.putText(frame, self.status_text, (4, 16),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1, cv2.LINE_AA)
        except Exception as e:  # noqa: BLE001
            self.get_logger().warn(f'camera_view: overlay draw failed: {e}')
            return

        try:
            out = bgr_to_imgmsg(frame, msg.header)
            self.pub.publish(out)
        except Exception as e:  # noqa: BLE001
            self.get_logger().warn(f'camera_view: publish failed: {e}')


def main(args=None):
    rclpy.init(args=args)
    node = CameraView()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
