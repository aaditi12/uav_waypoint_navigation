#!/usr/bin/env python3
"""
obstacle_avoidance.py

Reads the UAV's 360-degree LiDAR scan (/uav/scan) and, when something is
detected inside a forward cone within the safety distance, publishes a
suggested world-frame escape vector on /uav/obstacle_status. This is a pure
sensing/decision node - it does not move the vehicle itself; kinematic_controller
consumes this topic and blends the escape vector into its motion (real-time
reactive avoidance), keeping the two responsibilities cleanly separated.
"""
import math

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry

from uav_msgs.msg import ObstacleStatus


class ObstacleAvoidance(Node):
    def __init__(self):
        super().__init__('obstacle_avoidance')

        self.declare_parameter('safety_distance', 1.5)
        self.declare_parameter('forward_cone_deg', 90.0)  # +/- around heading
        self.safety_distance = self.get_parameter('safety_distance').value
        self.cone = math.radians(self.get_parameter('forward_cone_deg').value)

        self.yaw = 0.0
        self.status_pub = self.create_publisher(ObstacleStatus, '/uav/obstacle_status', 10)

        self.create_subscription(LaserScan, '/uav/scan', self._scan_cb, 10)
        self.create_subscription(Odometry, '/uav/odom', self._odom_cb, 10)

        self.get_logger().info('Obstacle avoidance node ready (LiDAR-based reactive avoidance).')

    def _odom_cb(self, msg: Odometry):
        q = msg.pose.pose.orientation
        siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        self.yaw = math.atan2(siny_cosp, cosy_cosp)

    def _scan_cb(self, msg: LaserScan):
        best_range = float('inf')
        best_angle = 0.0

        angle = msg.angle_min
        for r in msg.ranges:
            # only consider readings within the forward cone (relative to body heading)
            if -self.cone / 2.0 <= angle <= self.cone / 2.0:
                if msg.range_min < r < msg.range_max and r < best_range:
                    best_range = r
                    best_angle = angle
            angle += msg.angle_increment

        status = ObstacleStatus()
        if best_range < self.safety_distance:
            status.detected = True
            status.min_distance = float(best_range)
            status.min_angle = float(best_angle)

            # World-frame direction of the obstacle (body angle + current yaw)
            obs_world_angle = self.yaw + best_angle
            # Escape: steer away from the obstacle in the horizontal plane and
            # gently climb, which usually clears both walls and low obstacles.
            status.suggested_dx = float(-math.cos(obs_world_angle))
            status.suggested_dy = float(-math.sin(obs_world_angle))
            status.suggested_dz = 0.5
        else:
            status.detected = False
            status.min_distance = float(best_range) if best_range != float('inf') else -1.0
            status.min_angle = 0.0
            status.suggested_dx = 0.0
            status.suggested_dy = 0.0
            status.suggested_dz = 0.0

        self.status_pub.publish(status)


def main(args=None):
    rclpy.init(args=args)
    node = ObstacleAvoidance()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
