#!/usr/bin/env python3
"""
path_visualizer.py

Accumulates the UAV's actual flown trajectory from /uav/odom and republishes
it as a nav_msgs/Path on /uav/flown_path for live visualization in RViz2.
"""
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry, Path
from geometry_msgs.msg import PoseStamped


class PathVisualizer(Node):
    def __init__(self):
        super().__init__('path_visualizer')
        self.declare_parameter('max_points', 2000)
        self.declare_parameter('min_point_spacing', 0.05)
        self.max_points = self.get_parameter('max_points').value
        self.min_spacing = self.get_parameter('min_point_spacing').value

        self.path = Path()
        self.path.header.frame_id = 'map'
        self._last_xyz = None

        self.pub = self.create_publisher(Path, '/uav/flown_path', 10)
        self.create_subscription(Odometry, '/uav/odom', self._odom_cb, 10)

        self.get_logger().info('Path visualizer ready (/uav/flown_path).')

    def _odom_cb(self, msg: Odometry):
        p = msg.pose.pose.position
        if self._last_xyz is not None:
            lx, ly, lz = self._last_xyz
            d = ((p.x - lx) ** 2 + (p.y - ly) ** 2 + (p.z - lz) ** 2) ** 0.5
            if d < self.min_spacing:
                return
        self._last_xyz = (p.x, p.y, p.z)

        pose = PoseStamped()
        pose.header = msg.header
        pose.header.frame_id = 'map'
        pose.pose = msg.pose.pose
        self.path.poses.append(pose)
        if len(self.path.poses) > self.max_points:
            self.path.poses.pop(0)

        self.path.header.stamp = msg.header.stamp
        self.pub.publish(self.path)


def main(args=None):
    rclpy.init(args=args)
    node = PathVisualizer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
