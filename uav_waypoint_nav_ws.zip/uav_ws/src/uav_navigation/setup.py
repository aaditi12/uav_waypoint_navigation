from setuptools import find_packages, setup

package_name = 'uav_navigation'

setup(
    name=package_name,
    version='1.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Krishna',
    maintainer_email='krishna@example.com',
    description='Mission planning, obstacle avoidance, safety monitoring and visualization for the UAV',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'obstacle_avoidance = uav_navigation.obstacle_avoidance:main',
            'mission_manager = uav_navigation.mission_manager:main',
            'safety_monitor = uav_navigation.safety_monitor:main',
            'path_visualizer = uav_navigation.path_visualizer:main',
            'camera_view = uav_navigation.camera_view:main',
        ],
    },
)
