#!/usr/bin/env python3
"""
kinematic_controller.py

Owns the ground-truth pose of the simulated UAV. Since this project intentionally
avoids PX4 / full flight-dynamics simulation, the UAV is flown kinematically:
this node steps the current pose towards a commanded target pose at a bounded
linear/yaw rate and pushes that pose into Gazebo via the gazebo_ros_state
plugin's /gazebo/set_entity_state service. It also publishes odometry + TF so
the rest of the stack (RViz, Nav mission logic) has a normal ROS 2 view of the
vehicle.

A real-time reactive safety layer blends in an avoidance offset (published by
the obstacle_avoidance node) whenever an obstacle is detected close ahead, so
obstacle avoidance takes effect even mid-transit to a waypoint.
"""
import math

import rclpy
from rclpy.node import Node
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor

from geometry_msgs.msg import PoseStamped, Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Bool
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped

from gazebo_msgs.srv import SetEntityState
from gazebo_msgs.msg import EntityState

from uav_msgs.msg import ObstacleStatus
from uav_msgs.srv import GoToPose


def yaw_to_quat(yaw):
    return (0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0))


def quat_to_yaw(x, y, z, w):
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    return math.atan2(siny_cosp, cosy_cosp)


class KinematicController(Node):
    def __init__(self):
        super().__init__('uav_controller')

        self.declare_parameter('entity_name', 'uav')
        self.declare_parameter('max_lin_vel', 1.5)       # m/s
        self.declare_parameter('max_yaw_rate', 0.8)       # rad/s
        self.declare_parameter('control_rate', 20.0)      # Hz
        self.declare_parameter('safety_distance', 1.2)    # m
        self.declare_parameter('start_x', 0.0)
        self.declare_parameter('start_y', 0.0)
        self.declare_parameter('start_z', 0.1)

        self.entity_name = self.get_parameter('entity_name').value
        self.max_lin_vel = self.get_parameter('max_lin_vel').value
        self.max_yaw_rate = self.get_parameter('max_yaw_rate').value
        self.safety_distance = self.get_parameter('safety_distance').value
        rate = self.get_parameter('control_rate').value
        self.dt = 1.0 / rate

        x0 = self.get_parameter('start_x').value
        y0 = self.get_parameter('start_y').value
        z0 = self.get_parameter('start_z').value

        self.cur = {'x': x0, 'y': y0, 'z': z0, 'yaw': 0.0}
        self.target = dict(self.cur)

        self.emergency = False
        self.obstacle = ObstacleStatus()

        cb = ReentrantCallbackGroup()

        self.odom_pub = self.create_publisher(Odometry, '/uav/odom', 10)
        self.pose_pub = self.create_publisher(PoseStamped, '/uav/pose', 10)
        self.avoid_pub = self.create_publisher(Bool, '/uav/avoidance_active', 10)
        self.tf_bcast = TransformBroadcaster(self)

        self.create_subscription(ObstacleStatus, '/uav/obstacle_status',
                                  self._obstacle_cb, 10, callback_group=cb)
        self.create_subscription(Bool, '/uav/emergency_stop',
                                  self._emergency_cb, 10, callback_group=cb)
        # Also allow raw teleop / manual override for debugging
        self.create_subscription(Twist, '/uav/cmd_vel_manual',
                                  self._manual_cb, 10, callback_group=cb)

        self.set_state_cli = self.create_client(
            SetEntityState, '/gazebo/set_entity_state', callback_group=cb)

        self.goto_srv = self.create_service(
            GoToPose, '/uav/goto', self._goto_cb, callback_group=cb)

        self.timer = self.create_timer(self.dt, self._step, callback_group=cb)

        self.get_logger().info('Kinematic UAV controller ready. Waiting for /uav/goto requests.')

    # ---------------------------------------------------------------- utils
    def _obstacle_cb(self, msg: ObstacleStatus):
        self.obstacle = msg

    def _emergency_cb(self, msg: Bool):
        if msg.data and not self.emergency:
            self.get_logger().warn('EMERGENCY STOP received - freezing target pose (hover in place).')
            self.target = dict(self.cur)
        self.emergency = msg.data

    def _manual_cb(self, msg: Twist):
        # optional direct teleop hook; ignored while a mission goto is active
        pass

    # ------------------------------------------------------------- control
    def _step(self):
        dx = self.target['x'] - self.cur['x']
        dy = self.target['y'] - self.cur['y']
        dz = self.target['z'] - self.cur['z']
        dyaw = math.atan2(math.sin(self.target['yaw'] - self.cur['yaw']),
                           math.cos(self.target['yaw'] - self.cur['yaw']))

        dist = math.sqrt(dx * dx + dy * dy + dz * dz)
        avoiding = False

        if not self.emergency and dist > 1e-3:
            step = min(self.max_lin_vel * self.dt, dist)
            ux, uy, uz = dx / dist, dy / dist, dz / dist

            # Blend in reactive avoidance if something is close in front
            if self.obstacle.detected and self.obstacle.min_distance < self.safety_distance:
                avoiding = True
                blend = 0.75
                ux = (1 - blend) * ux + blend * self.obstacle.suggested_dx
                uy = (1 - blend) * uy + blend * self.obstacle.suggested_dy
                uz = (1 - blend) * uz + blend * self.obstacle.suggested_dz
                norm = math.sqrt(ux * ux + uy * uy + uz * uz) or 1.0
                ux, uy, uz = ux / norm, uy / norm, uz / norm

            self.cur['x'] += ux * step
            self.cur['y'] += uy * step
            self.cur['z'] += uz * step

        if not self.emergency and abs(dyaw) > 1e-3:
            ystep = max(-self.max_yaw_rate * self.dt, min(self.max_yaw_rate * self.dt, dyaw))
            self.cur['yaw'] += ystep

        self.avoid_pub.publish(Bool(data=avoiding))
        self._publish_state()
        self._push_to_gazebo()

    def _publish_state(self):
        now = self.get_clock().now().to_msg()
        qx, qy, qz, qw = yaw_to_quat(self.cur['yaw'])

        odom = Odometry()
        odom.header.stamp = now
        odom.header.frame_id = 'map'
        odom.child_frame_id = 'base_link'
        odom.pose.pose.position.x = self.cur['x']
        odom.pose.pose.position.y = self.cur['y']
        odom.pose.pose.position.z = self.cur['z']
        odom.pose.pose.orientation.x = qx
        odom.pose.pose.orientation.y = qy
        odom.pose.pose.orientation.z = qz
        odom.pose.pose.orientation.w = qw
        self.odom_pub.publish(odom)

        pose = PoseStamped()
        pose.header = odom.header
        pose.pose = odom.pose.pose
        self.pose_pub.publish(pose)

        t = TransformStamped()
        t.header.stamp = now
        t.header.frame_id = 'map'
        t.child_frame_id = 'base_link'
        t.transform.translation.x = self.cur['x']
        t.transform.translation.y = self.cur['y']
        t.transform.translation.z = self.cur['z']
        t.transform.rotation.x = qx
        t.transform.rotation.y = qy
        t.transform.rotation.z = qz
        t.transform.rotation.w = qw
        self.tf_bcast.sendTransform(t)

    def _push_to_gazebo(self):
        if not self.set_state_cli.service_is_ready():
            return
        qx, qy, qz, qw = yaw_to_quat(self.cur['yaw'])
        req = SetEntityState.Request()
        req.state = EntityState()
        req.state.name = self.entity_name
        req.state.reference_frame = 'world'
        req.state.pose.position.x = self.cur['x']
        req.state.pose.position.y = self.cur['y']
        req.state.pose.position.z = self.cur['z']
        req.state.pose.orientation.x = qx
        req.state.pose.orientation.y = qy
        req.state.pose.orientation.z = qz
        req.state.pose.orientation.w = qw
        self.set_state_cli.call_async(req)  # fire and forget, best effort

    # --------------------------------------------------------------- goto
    def _goto_cb(self, request, response):
        if self.emergency:
            response.success = False
            response.message = 'Refused: UAV is in EMERGENCY state.'
            return response

        yaw = quat_to_yaw(request.target.orientation.x, request.target.orientation.y,
                           request.target.orientation.z, request.target.orientation.w)
        self.target = {
            'x': request.target.position.x,
            'y': request.target.position.y,
            'z': request.target.position.z,
            'yaw': yaw,
        }
        tol = request.tolerance if request.tolerance > 0 else 0.25
        timeout = request.timeout if request.timeout > 0 else 60.0

        elapsed = 0.0
        poll = 0.1
        while rclpy.ok() and elapsed < timeout:
            if self.emergency:
                response.success = False
                response.message = 'Aborted: EMERGENCY STOP triggered mid-flight.'
                return response
            d = math.sqrt((self.target['x'] - self.cur['x']) ** 2 +
                           (self.target['y'] - self.cur['y']) ** 2 +
                           (self.target['z'] - self.cur['z']) ** 2)
            if d <= tol:
                response.success = True
                response.message = 'Reached target pose.'
                return response
            self.get_clock().sleep_for(rclpy.duration.Duration(seconds=poll))
            elapsed += poll

        response.success = False
        response.message = 'Timed out before reaching target pose.'
        return response


def main(args=None):
    rclpy.init(args=args)
    node = KinematicController()
    executor = MultiThreadedExecutor(num_threads=4)
    executor.add_node(node)
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
