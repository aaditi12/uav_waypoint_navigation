#!/usr/bin/env python3
"""
takeoff_land_node.py

Provides two simple Trigger services:
  /uav/takeoff  - climbs straight up from the current x,y to a cruise altitude
  /uav/land     - descends straight down to the ground at the current x,y

Both are implemented as thin wrappers around the /uav/goto service exposed by
kinematic_controller, so the actual motion (and any obstacle-avoidance
blending) is handled in one place.
"""
import time

import rclpy
from rclpy.node import Node
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor

from std_srvs.srv import Trigger
from nav_msgs.msg import Odometry
from uav_msgs.srv import GoToPose


class TakeoffLandNode(Node):
    def __init__(self):
        super().__init__('takeoff_land_node')
        self.declare_parameter('cruise_altitude', 3.0)
        self.declare_parameter('ground_altitude', 0.1)
        self.cruise_alt = self.get_parameter('cruise_altitude').value
        self.ground_alt = self.get_parameter('ground_altitude').value

        cb = ReentrantCallbackGroup()
        self.last_odom = None
        self.create_subscription(Odometry, '/uav/odom', self._odom_cb, 10, callback_group=cb)

        self.goto_cli = self.create_client(GoToPose, '/uav/goto', callback_group=cb)

        self.create_service(Trigger, '/uav/takeoff', self._takeoff_cb, callback_group=cb)
        self.create_service(Trigger, '/uav/land', self._land_cb, callback_group=cb)

        self.get_logger().info('Takeoff/Land node ready (/uav/takeoff, /uav/land).')

    def _odom_cb(self, msg: Odometry):
        self.last_odom = msg

    def _current_xy(self):
        if self.last_odom is None:
            return 0.0, 0.0
        p = self.last_odom.pose.pose.position
        return p.x, p.y

    def _call_goto(self, x, y, z, tolerance=0.2, timeout=30.0):
        if not self.goto_cli.wait_for_service(timeout_sec=5.0):
            return False, 'goto service unavailable'
        req = GoToPose.Request()
        req.target.position.x = x
        req.target.position.y = y
        req.target.position.z = z
        req.target.orientation.w = 1.0
        req.tolerance = tolerance
        req.timeout = timeout
        future = self.goto_cli.call_async(req)
        # NOTE: this node already runs under a MultiThreadedExecutor, whose worker
        # threads are what actually complete this future in the background, so we
        # just poll rather than nesting another spin call (which is unsafe here).
        waited = 0.0
        poll = 0.1
        while not future.done() and waited < timeout + 5.0:
            time.sleep(poll)
            waited += poll
        if not future.done() or future.result() is None:
            return False, 'goto call failed / timed out'
        res = future.result()
        return res.success, res.message

    def _takeoff_cb(self, request, response):
        x, y = self._current_xy()
        self.get_logger().info(f'Takeoff: climbing to {self.cruise_alt:.1f} m.')
        ok, msg = self._call_goto(x, y, self.cruise_alt)
        response.success = ok
        response.message = f'Takeoff {"complete" if ok else "failed"}: {msg}'
        return response

    def _land_cb(self, request, response):
        x, y = self._current_xy()
        self.get_logger().info('Landing: descending to ground level.')
        ok, msg = self._call_goto(x, y, self.ground_alt, tolerance=0.1)
        response.success = ok
        response.message = f'Landing {"complete" if ok else "failed"}: {msg}'
        return response


def main(args=None):
    rclpy.init(args=args)
    node = TakeoffLandNode()
    executor = MultiThreadedExecutor(num_threads=2)
    executor.add_node(node)
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
