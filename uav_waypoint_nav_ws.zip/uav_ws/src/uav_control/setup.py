from setuptools import find_packages, setup

package_name = 'uav_control'

setup(
    name=package_name,
    version='1.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Krishna',
    maintainer_email='krishna@example.com',
    description='Kinematic flight controller and takeoff/land services for the simulated UAV',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'kinematic_controller = uav_control.kinematic_controller:main',
            'takeoff_land_node = uav_control.takeoff_land_node:main',
        ],
    },
)
