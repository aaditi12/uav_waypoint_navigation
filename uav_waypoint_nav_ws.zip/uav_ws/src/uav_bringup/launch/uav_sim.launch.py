import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction, DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    bringup_pkg = get_package_share_directory('uav_bringup')
    gazebo_pkg = get_package_share_directory('uav_gazebo')

    params_file = os.path.join(bringup_pkg, 'config', 'waypoints.yaml')
    rviz_config = os.path.join(bringup_pkg, 'rviz', 'uav_config.rviz')

    use_rviz = LaunchConfiguration('use_rviz')
    auto_start = LaunchConfiguration('auto_start')

    declare_use_rviz = DeclareLaunchArgument('use_rviz', default_value='true')
    declare_auto_start = DeclareLaunchArgument(
        'auto_start', default_value='false',
        description='If true, mission starts automatically 5s after mission_manager comes up.')

    world_and_uav = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(gazebo_pkg, 'launch', 'spawn_uav.launch.py')
        )
    )

    kinematic_controller = Node(
        package='uav_control',
        executable='kinematic_controller',
        name='uav_controller',
        output='screen',
        parameters=[params_file, {'use_sim_time': True}]
    )

    takeoff_land = Node(
        package='uav_control',
        executable='takeoff_land_node',
        name='takeoff_land_node',
        output='screen',
        parameters=[params_file, {'use_sim_time': True}]
    )

    obstacle_avoidance = Node(
        package='uav_navigation',
        executable='obstacle_avoidance',
        name='obstacle_avoidance',
        output='screen',
        parameters=[params_file, {'use_sim_time': True}]
    )

    safety_monitor = Node(
        package='uav_navigation',
        executable='safety_monitor',
        name='safety_monitor',
        output='screen',
        parameters=[params_file, {'use_sim_time': True}]
    )

    path_visualizer = Node(
        package='uav_navigation',
        executable='path_visualizer',
        name='path_visualizer',
        output='screen',
        parameters=[{'use_sim_time': True}]
    )

    camera_view = Node(
        package='uav_navigation',
        executable='camera_view',
        name='camera_view',
        output='screen',
        parameters=[{'use_sim_time': True}]
    )

    mission_manager = Node(
        package='uav_navigation',
        executable='mission_manager',
        name='mission_manager',
        output='screen',
        parameters=[params_file, {'use_sim_time': True, 'auto_start': auto_start}]
    )

    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', rviz_config],
        parameters=[{'use_sim_time': True}],
        condition=IfCondition(use_rviz)
    )

    ld = LaunchDescription([declare_use_rviz, declare_auto_start, world_and_uav])

    # Bring up the ROS 2 stack a few seconds after the UAV has spawned in Gazebo
    ld.add_action(TimerAction(period=8.0, actions=[
        kinematic_controller, takeoff_land, obstacle_avoidance,
        safety_monitor, path_visualizer, camera_view,
    ]))
    ld.add_action(TimerAction(period=9.0, actions=[mission_manager]))
    ld.add_action(TimerAction(period=10.0, actions=[rviz]))

    return ld
