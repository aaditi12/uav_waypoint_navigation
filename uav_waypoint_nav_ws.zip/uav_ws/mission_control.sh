#!/bin/bash
# Convenience wrapper for the UAV mission services.
# Run `bash run.sh` first in another terminal, then use this once Gazebo/RViz are up.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source /opt/ros/humble/setup.bash
source "$SCRIPT_DIR/install/setup.bash"

cmd="$1"

case "$cmd" in
  start)
    echo "Starting mission (takeoff -> waypoints -> RTH -> land)..."
    ros2 service call /uav/start_mission std_srvs/srv/Trigger {}
    ;;
  rth|return)
    echo "Commanding return-to-home..."
    ros2 service call /uav/return_home std_srvs/srv/Trigger {}
    ;;
  emergency|stop)
    echo "Triggering EMERGENCY STOP (hover in place, then safe landing)..."
    ros2 service call /uav/trigger_emergency std_srvs/srv/Trigger {}
    ;;
  clear)
    echo "Clearing emergency state..."
    ros2 service call /uav/clear_emergency std_srvs/srv/Trigger {}
    ;;
  status)
    ros2 topic echo /uav/mission_status --once
    ;;
  battery)
    ros2 topic echo /uav/battery_state --once
    ;;
  *)
    echo "Usage: bash mission_control.sh {start|rth|emergency|clear|status|battery}"
    exit 1
    ;;
esac
